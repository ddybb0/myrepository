这是一个kaggle机器学习项目
任务类型：二分类任务
数据类型：结构化数据
Dataset Description

File descriptions
train.csv - the training set
test.csv - the test set
sampleSubmission.csv - a sample submission file in the correct format

Data fields
Home Ownership - домовладение
Annual Income - годовой доход
Years in current job - количество лет на текущем месте работы
Tax Liens - налоговые обременения
Number of Open Accounts - количество открытых счетов
Years of Credit History - количество лет кредитной истории
Maximum Open Credit - наибольший открытый кредит
Number of Credit Problems - количество проблем с кредитом
Months since last delinquent - количество месяцев с последней просрочки платежа
Bankruptcies - банкротства
Purpose - цель кредита
Term - срок кредита
Current Loan Amount - текущая сумма кредита
Current Credit Balance - текущий кредитный баланс
Monthly Debt - ежемесячный долг
Credit Default - факт невыполнения кредитных обязательств (0 - погашен вовремя, 1 - просрочка)